/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anna
 */
public class MyMath {
    public static double cosh ( double x ){
        double s = 0 , term = 1 ;
        int n = 0 ;
        while ( term >= 0.00001 ) {
        s = s + term ;
        n++ ;
        term = term * ( Math.pow(x, 2) / ((2 * n )*(2*n-1)))  ;      
        
                }  
        return s ;
}
}