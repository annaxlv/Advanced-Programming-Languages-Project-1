/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author math18244
 */
public class Exercise1 {

 public  static void main(String[] args) {
 int num = 0 , val = 0; /* έκανα αυτές τις δυο αρχικοποιήσεις γιατί στις σειρές 15 και 16 μου έβγαζε error και η παρατήριση ήταν οτιδεν ήταν αρχικοποιημένες οι μεταβλητές*/
  
 if (val == 0)
 num = 12;
 else if (val > 0)
 num = 5;
 
 System.out.println(num);
 }
 }
    
