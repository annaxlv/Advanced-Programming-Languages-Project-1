/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anna
 */
public class MyMath {
    public static void gaussSeidel(double a[][],double b[],double x[]){
    double x_old[] = new double[x.length];
    int i , j;
    for (i=0;i< x.length;i++){
        x_old[i]= 0.0;
    }
    while(true){
        for(i=0;i<x.length;i++){
            double S1=0.0;
                    for(j=0;j<=i-1;j++){
                        S1 = S1 + a[i][j]*x[j];
                    }
            double S2 = 0.0 ;
                    for(j=i+1;j<x.length;j++){
                        S2 = S2 + a[i][j]*x_old[j];
                    }
            x[i] = (b[i]- S1- S2)/a[i][i];
        }
        double max= -1;
        for(i=0;i<x.length;i++){
            if(max< Math.abs(x[i]-x_old[i])){
                max= Math.abs(x[i]-x_old[i]);
            }
        }
        if(max<0.00001){
            break;
        }
        for(i=0;i<x.length;i++){
            x_old[i]=x[i];
        }
    }
    }

    public static void main(String argv[]){
        double b[]={7,12,15};
        double x[]= new double[b.length];
        double a[][]={{7,3,-2},{2,5,0},{1,-2,6}};
        int i ;
        gaussSeidel(a,b,x);
        for(i=0;i<x.length;i++){
           System.out.println(x[i]);
        }
    }
                
}
